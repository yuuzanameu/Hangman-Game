module Main (main) where

import Lib
import Data.List
-- import System.Random (randomRIO)


main :: IO ()
main = do
    file <- readFile "data/words.txt" 
    print $ take 10 file